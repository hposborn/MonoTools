import os
DATADIR = os.environ['ISOCLASSIFY']

from .isoclassify import *
#from isoclassify.grid import *
#classify_grid, priors, match, plot, single, pdf
#import grid.classify_grid
#import grid.priors
#import grid.match
#import grid.plot
#import grid.single
#import grid.pdf
